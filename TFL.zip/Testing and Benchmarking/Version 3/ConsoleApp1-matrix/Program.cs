﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Xml.Linq;
using static System.Collections.Specialized.BitVector32;



namespace TFLShortestPathFinder
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //creating a Graph object and adding Station objects to the graph
            Graph graph = new Graph();

            graph.CreateGraph(graph);

            //adjacency matrix using the graph.CreateAdjMatrix() method and initializes some data structures and variables needed for Dijkstra's algorithm

            int[,] adj = graph.CreateAdjMatrix();
            int[,] adj_backup = adj;

            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("Please select your Role");
                Console.WriteLine("1 - Admin");
                Console.WriteLine("2 - Customer");
                int roleChoice = Convert.ToInt32(Console.ReadLine());

                switch (roleChoice)
                {
                    case 1:
                        Console.WriteLine("Please select an option:");
                        Console.WriteLine("1. Add/remove journey walking time delays");
                        Console.WriteLine("2. Mark route as impossible/possible");
                        Console.WriteLine("3. Print impossible walking routes");
                        Console.WriteLine("4. Print delayed walking routes");
                        Console.WriteLine("5. Exit");

                        int adminChoice = Convert.ToInt32(Console.ReadLine());

                        switch (adminChoice)
                        {
                            case 1:
                                // Call the function to add/remove delays
                                graph.AddRemoveDelays();
                                adj = graph.CreateAdjMatrix();
                                break;
                            case 2:
                                Console.WriteLine("Enter the starting station:");
                                string startStationName = Console.ReadLine();
                                Console.WriteLine("Enter the ending station:");
                                string endStationName = Console.ReadLine();

                                Console.WriteLine("Enter 1 to mark the route as possible or 0 to mark it as impossible:");
                                int possibleInput = Convert.ToInt32(Console.ReadLine());
                                bool isPossible = possibleInput == 1;

                                graph.MarkRoutePossibleOrImpossible(startStationName, endStationName, isPossible);
                                break;
                            case 3:
                                // Call the function to print impossible walking routes
                                graph.PrintImpossibleWalkingRoutes();
                                break;
                            case 4:
                                // Call the function to print delayed walking routes
                                graph.PrintDelayedWalkingRoutes(adj, adj_backup);
                                break;
                            default:
                                break;

                        }
                        break;
                    case 2:
                        Console.WriteLine("Please select an option:");
                        Console.WriteLine("1. Find the fastest walking route");
                        Console.WriteLine("2. Display Tube Information");
                        Console.WriteLine("3.  Exit");

                        int customerChoice = Convert.ToInt32(Console.ReadLine());

                        switch (customerChoice)
                        {
                            case 1:
                                // Call the function to find the fastest walking route
                                Console.WriteLine("Enter the source station name:");
                                string sourceName = Console.ReadLine();
                                Console.WriteLine("Enter the target station name:");
                                string targetName = Console.ReadLine();


                                Station source = Station.FindStationByName(sourceName, graph.stations);
                                Station target = Station.FindStationByName(targetName, graph.stations);

                                if (source == null || target == null)
                                {
                                    Console.WriteLine("Invalid source or target station name. Please make sure you entered the correct names.");
                                    return; // or you can use a loop to ask for input again
                                }

                                graph.DijkestraAlgorithm(source, target, graph, adj);
                                break;
                            case 2:
                                Console.WriteLine("Please enter the Tube to Display its Information");
                                string name = Console.ReadLine();

                                Station station = Station.FindStationByName(name, graph.stations);
                                Console.WriteLine(station.ToString());
                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }
    }
}

