﻿namespace TFLShortestPathFinder_matrix.Enum
{
    public enum StationAccess
    {
        Stairs,
        StepFreeAccessFromStreetToTrain,
        StepFreeAccessFromStreettoPlatform
    }
}
