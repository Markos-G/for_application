﻿namespace UndirectedWeightedGraph.Enum
{
    public enum StationAccess
    {
        Stairs,
        StepFreeAccessFromStreetToTrain,
        StepFreeAccessFromStreettoPlatform
    }
}
