﻿//program creates an undirected weighted graph, adds stations,
//establishes connections between them using AddTwoWayEdge,
//and then runs the Dijkstra algorithm to find the shortest path between the given source and target stations
namespace UndirectedWeightedGraph
{
    internal class Program
    {
        public static void Main(string[] args)
        {

            //create an instance of the Graph class
            Graph graph = new Graph();

            graph = graph.CreateGraph(graph);

            
            //CreateAdjList() method to create an adjacency list representation of the graph
            //Each entry in the list represents a station,
            //and the custom linked list at that entry contains the edges connecting that station to its neighbors
            MyList<MyLinkedList> adj = graph.CreateAdjList();
            MyList<MyLinkedList> adj2 = adj;
            bool exit = false;
            while (!exit)
            {
                Console.WriteLine();
                Console.WriteLine("Please select your Role ");
                Console.WriteLine("1 - Admin");
                Console.WriteLine("2 - Customer");
                int roleChoice = Convert.ToInt32(Console.ReadLine());

                switch (roleChoice)
                {
                    case 1:
                        Console.WriteLine("Please select an option:");
                        Console.WriteLine("1. Add/remove journey walking time delays");
                        Console.WriteLine("2. Mark route as impossible/possible");
                        Console.WriteLine("3. Print impossible walking routes");
                        Console.WriteLine("4. Print delayed walking routes");
                        Console.WriteLine("5. Exit");

                        int adminChoice = Convert.ToInt32(Console.ReadLine());
                        switch (adminChoice)
                        {
                            case 1:
                                // Add this code where you want to add/remove delays and update the adjacency list
                                graph.AddRemoveDelays();
                                // This line updates the adjacency list after adding/removing delays
                                adj = graph.CreateAdjList(); 

                                break;
                            case 2:
                           
                                Console.WriteLine("Enter the starting station:");
                                string startStationName = Console.ReadLine();
                                Console.WriteLine("Enter the ending station:");
                                string endStationName = Console.ReadLine();

                                Console.WriteLine("Enter 1 to mark the route as possible or 0 to mark it as impossible:");
                                int possibleInput = Convert.ToInt32(Console.ReadLine());
                                bool isPossible = possibleInput == 1;

                                graph.MarkRoutePossibleOrImpossible(startStationName, endStationName, isPossible);
                             
                                break;
                            case 3:
                                // Call the function to print impossible walking routes
                                graph.PrintImpossibleWalkingRoutes();
                                break;
                            case 4:
                                graph.PrintDelayedWalkingRoutes(adj, adj2);
                                break;
                            default:
                                break;
                        }
                        break;
                    case 2:
                        Console.WriteLine("Please select an option:");
                        Console.WriteLine("1. Find the fastest walking route");
                        Console.WriteLine("2. Display Tube Information");
                        Console.WriteLine("3.  Exit");

                        int customerChoice = Convert.ToInt32(Console.ReadLine());
                        switch (customerChoice)
                        {
                            case 1:
                                // Call the function to find the fastest walking route
                                Console.WriteLine("Enter the source station name:");
                                string sourceName = Console.ReadLine();
                                Console.WriteLine("Enter the target station name:");
                                string targetName = Console.ReadLine();

                                Station source = graph.GetStationByName(sourceName);
                                Station target = graph.GetStationByName(targetName);

                                if (source == null || target == null)
                                {
                                    Console.WriteLine("Invalid source or target station name. Please make sure you entered the correct names.");
                                    break; // or you can use a loop to ask for input again
                                }

                                graph.DijkstraAlgorithem(source, target, graph,adj);

                                break;
                            case 2:
                                Console.WriteLine("Please enter the Tube to Display its Information");
                                string name = Console.ReadLine();

                                Station station = graph.GetStationByName(name);
                                if (station != null)
                                {
                                    Console.WriteLine(station.ToString());
                                }
                                else
                                {
                                    Console.WriteLine("Invalid station name. Please make sure you entered the correct name.");
                                }
                                break;
                            default:
                                break;
                        }
                        break;

                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }
    }
}