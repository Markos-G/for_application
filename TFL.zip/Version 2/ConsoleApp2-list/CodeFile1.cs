﻿namespace UndirectedWeightedGraph.Enum
{
    internal enum StationAccess
    {
        Stairs,
        StepFreeAccessFromStreetToTrain,
        StepFreeAccessFromStreettoPlatform
    }
}
